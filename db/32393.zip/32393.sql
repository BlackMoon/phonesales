﻿-- Скрипт сгенерирован Devart dbForge Studio for MySQL, Версия 6.1.166.0
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 09.06.2014 23:45:55
-- Версия сервера: 5.6.19
-- Версия клиента: 4.1

-- 
-- Отключение внешних ключей
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- Установить режим SQL (SQL mode)
-- 
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 
-- Установка кодировки, с использованием которой клиент будет посылать запросы на сервер
--
SET NAMES 'utf8';

-- 
-- Установка базы данных по умолчанию
--
USE `32393`;

--
-- Описание для таблицы manufactors
--
DROP TABLE IF EXISTS manufactors;
CREATE TABLE manufactors (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  PRIMARY KEY (id)
)
ENGINE = MYISAM
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

--
-- Описание для таблицы offices
--
DROP TABLE IF EXISTS offices;
CREATE TABLE offices (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE INDEX name (name)
)
ENGINE = MYISAM
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

--
-- Описание для таблицы phones
--
DROP TABLE IF EXISTS phones;
CREATE TABLE phones (
  id INT(11) NOT NULL AUTO_INCREMENT,
  year INT(4) DEFAULT NULL,
  name VARCHAR(255) NOT NULL,
  manufactorid INT(11) DEFAULT NULL COMMENT 'Производитель',
  PRIMARY KEY (id)
)
ENGINE = MYISAM
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

--
-- Описание для таблицы sales
--
DROP TABLE IF EXISTS sales;
CREATE TABLE sales (
  id INT(11) NOT NULL AUTO_INCREMENT,
  phoneid INT(11) NOT NULL,
  officeid INT(11) NOT NULL,
  saledate DATE DEFAULT NULL,
  PRIMARY KEY (id)
)
ENGINE = MYISAM
AUTO_INCREMENT = 1
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы users
--
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INT(11) NOT NULL AUTO_INCREMENT,
  login VARCHAR(255) NOT NULL,
  password VARCHAR(255) NOT NULL,
  salt VARCHAR(255) DEFAULT NULL,
  lastname VARCHAR(255) NOT NULL,
  firstname VARCHAR(255) NOT NULL,
  middlename VARCHAR(255) NOT NULL,
  isadmin INT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE INDEX login (login)
)
ENGINE = MYISAM
AUTO_INCREMENT = 17
AVG_ROW_LENGTH = 4611
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

-- 
-- Вывод данных для таблицы manufactors
--

-- Таблица `32393`.manufactors не содержит данных

-- 
-- Вывод данных для таблицы offices
--

-- Таблица `32393`.offices не содержит данных

-- 
-- Вывод данных для таблицы phones
--

-- Таблица `32393`.phones не содержит данных

-- 
-- Вывод данных для таблицы sales
--

-- Таблица `32393`.sales не содержит данных

-- 
-- Вывод данных для таблицы users
--
INSERT INTO users VALUES
(13, 'admin', 'ece17a9d98d1fb03a4595e4c74be0c7e2427e79d87643f90a907985d41c405dc', '295b5c5251e555b1', 'Админов', 'Админ', 'Админович', 1),
(15, 'user', 'ccb9c253d300ed62585409f6b2a38b4f731d10ccd942164aa7be1d6e67232aa5', 'a697c60af2930a25', 'Пользователев', 'Пользователь', 'Пользователевич', 0);

-- 
-- Восстановить предыдущий режим SQL (SQL mode)
-- 
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;

-- 
-- Включение внешних ключей
-- 
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;