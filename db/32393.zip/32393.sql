﻿-- Скрипт сгенерирован Devart dbForge Studio for MySQL, Версия 6.0.568.0
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 10.06.2014 12:50:23
-- Версия сервера: 5.6.19
-- Версия клиента: 4.1

-- 
-- Отключение внешних ключей
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- Установка кодировки, с использованием которой клиент будет посылать запросы на сервер
--
SET NAMES 'utf8';

-- 
-- Установка базы данных по умолчанию
--
USE `32393`;

--
-- Описание для таблицы manufactors
--
DROP TABLE IF EXISTS manufactors;
CREATE TABLE manufactors (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  country VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (id)
)
ENGINE = MYISAM
AUTO_INCREMENT = 13
AVG_ROW_LENGTH = 1539
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

--
-- Описание для таблицы offices
--
DROP TABLE IF EXISTS offices;
CREATE TABLE offices (
  id INT(11) NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  address VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE INDEX name (name)
)
ENGINE = MYISAM
AUTO_INCREMENT = 6
AVG_ROW_LENGTH = 1539
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

--
-- Описание для таблицы phones
--
DROP TABLE IF EXISTS phones;
CREATE TABLE phones (
  id INT(11) NOT NULL AUTO_INCREMENT,
  year INT(4) DEFAULT NULL,
  manufactorid INT(11) DEFAULT NULL COMMENT 'Производитель',
  model VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (id),
  INDEX FK_03eb6736964546dc9260d39fcc6 (manufactorid),
  INDEX FK_09b8340621ea446e81d1f51936d (manufactorid),
  INDEX FK_09ea71e98edb495ead1d0e4f28d (manufactorid),
  INDEX FK_0b0cc8188eb144e19adb7a8f9b5 (manufactorid),
  INDEX FK_0cf56661f0f941039f05a93b056 (manufactorid),
  INDEX FK_0f51931ebd5e47adbddb66bfc36 (manufactorid),
  INDEX FK_10364acfaeea4f6dbae78f1b607 (manufactorid),
  INDEX FK_12ef7eaa4dac47e49d160d7ea4d (manufactorid),
  INDEX FK_15cbc289d9494c7cafecd23d861 (manufactorid),
  INDEX FK_18455d9fe0984928b10d1543fd0 (manufactorid),
  INDEX FK_188d9c8302d4440484caf5a8bb2 (manufactorid),
  INDEX FK_1a03f9d6a15f46a39d8323b562a (manufactorid),
  INDEX FK_1b620ab41d424a15bef7ac63b80 (manufactorid),
  INDEX FK_1d9e17f92f04437cafcd8d011ee (manufactorid),
  INDEX FK_1e310d1e056f423f82754ff95bc (manufactorid),
  INDEX FK_2f92959e474b46fd95d4e05932c (manufactorid),
  INDEX FK_34d8a0f7d9bf4c6b8df4e85086d (manufactorid),
  INDEX FK_34e8ccfa3113474a99c7f1f90cc (manufactorid),
  INDEX FK_3562a0f959bd434c96b6f0d67be (manufactorid),
  INDEX FK_40221e2335b8423a9ea461711c8 (manufactorid),
  INDEX FK_405548359a874bf99bbf728684c (manufactorid),
  INDEX FK_44b7955bbfd64a76a057cf1bc91 (manufactorid),
  INDEX FK_4a43c546342f4c7a873cb977437 (manufactorid),
  INDEX FK_516672449fbf444aa7e16e58aa7 (manufactorid),
  INDEX FK_52271f8bfd004d96bcba52c95fa (manufactorid),
  INDEX FK_54841b07e09b4ab8abbf8e7830c (manufactorid),
  INDEX FK_63148ffc22c8425da9b2b978a98 (manufactorid),
  INDEX FK_65a2618ecb8d4ea79dc64fa1ec5 (manufactorid),
  INDEX FK_65e933dee2274a00b2bd7daa3c8 (manufactorid),
  INDEX FK_6920c1b8c23b401ab329dbba3da (manufactorid),
  INDEX FK_69429495586b420dab021fc428c (manufactorid),
  INDEX FK_6a06a6fe893a45db94c02764086 (manufactorid),
  INDEX FK_733336bb946f468bacb8ad34887 (manufactorid),
  INDEX FK_7401dd88b4dc41529b89defb9cb (manufactorid),
  INDEX FK_7c79742e4a8b4f67be22c348a25 (manufactorid),
  INDEX FK_7d3d39c369e84ccb8efc857cecc (manufactorid),
  INDEX FK_84bc6cf0f70d4d80a561d5a0693 (manufactorid),
  INDEX FK_88d60278b03d48ecbde6fb867b2 (manufactorid),
  INDEX FK_8cb77f83eaca4afba471f31c5a1 (manufactorid),
  INDEX FK_8efb451cb0554b37bc441cd531c (manufactorid),
  INDEX FK_91a12f5423c249a59edf1da14d8 (manufactorid),
  INDEX FK_94102a3dd18e4cd48d4f5312386 (manufactorid),
  INDEX FK_944c3b18d586463aab0e92f58eb (manufactorid),
  INDEX FK_a55eea9c1cad4033b81552ba0d1 (manufactorid),
  INDEX FK_a5ec43067e2b467f8d4327a4d69 (manufactorid),
  INDEX FK_a8e02b26874348e796f3188431f (manufactorid),
  INDEX FK_b9121363fbb74c529361224a1a1 (manufactorid),
  INDEX FK_c04b667f379445f4b97494c001e (manufactorid),
  INDEX FK_c3a48d493d384bf9bcd93a305c9 (manufactorid),
  INDEX FK_c802cf37d8694884aeb5a3367e3 (manufactorid),
  INDEX FK_ce7b3c7d7680459fa09cfab33f4 (manufactorid),
  INDEX FK_d239aed9f21f4212af13ea718c3 (manufactorid),
  INDEX FK_d63612505b2a458ab57bb71113b (manufactorid),
  INDEX FK_d7546b0a2d4a43d59da640f45e9 (manufactorid),
  INDEX FK_d8d1f6d0667b492aa116dcd25ff (manufactorid),
  INDEX FK_e30a0700d38d4c40853e9a5a2dc (manufactorid),
  INDEX FK_ea689f0bb8e3498a81cf3a9482a (manufactorid),
  INDEX FK_f1c1f66197644eba8daa68d2978 (manufactorid),
  INDEX FK_f3910e9143a44ba9aaf6ec81eb8 (manufactorid),
  INDEX FK_f3ba02a29da24b129827f6aea91 (manufactorid),
  INDEX FK_f45414ef51334cd18d455fbc76b (manufactorid),
  INDEX FK_f5336f4ff44449f980f8840be39 (manufactorid),
  INDEX FK_fced01417ca24e30a4f91b4aa88 (manufactorid)
)
ENGINE = MYISAM
AUTO_INCREMENT = 20
AVG_ROW_LENGTH = 780
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

--
-- Описание для таблицы sales
--
DROP TABLE IF EXISTS sales;
CREATE TABLE sales (
  id INT(11) NOT NULL AUTO_INCREMENT,
  phoneid INT(11) NOT NULL,
  officeid INT(11) NOT NULL,
  saledate DATE DEFAULT NULL,
  price DECIMAL(10, 2) DEFAULT NULL,
  PRIMARY KEY (id),
  INDEX FK_0cc95a7522d14549ac07348098d (officeid),
  INDEX FK_0db9eb23682d442a8754a8fa821 (phoneid),
  INDEX FK_15dc45d27a9543c79ebd4d697b1 (phoneid),
  INDEX FK_16aa2bf5027f447b86c686ec415 (phoneid),
  INDEX FK_18ac1e02a9064303be6fa5341f5 (officeid),
  INDEX FK_1a89f29bbdf54f2e8bf8dcc8248 (phoneid),
  INDEX FK_1b293737335447abaf9f2bb9878 (phoneid),
  INDEX FK_1f32e0c7fe63425086f0b0156a6 (officeid),
  INDEX FK_21e8e385d58b453aa5235140339 (officeid),
  INDEX FK_2e625602ef4844329e326f359a9 (phoneid),
  INDEX FK_315597c031674b82b3876b4f51a (phoneid),
  INDEX FK_34b0790306514ca2bb9c2d25f92 (officeid),
  INDEX FK_3b50454175ff4e42bebb8856a1c (phoneid),
  INDEX FK_45b96b5a890c42e1934cec28893 (phoneid),
  INDEX FK_476646497acf41af834a4f91976 (officeid),
  INDEX FK_48042fa79c6c4b85ba67d936150 (officeid),
  INDEX FK_484a5b8ab42948a586500dc0fee (phoneid),
  INDEX FK_4859e0844ef24146b606310e64a (officeid),
  INDEX FK_48d16edcd6b14ca68c7ee71ceec (phoneid),
  INDEX FK_50588461531a4915959ab771c6f (officeid),
  INDEX FK_56772cc7417b491a92ef7297760 (officeid),
  INDEX FK_58c097b5264d4a86b3660d7490f (phoneid),
  INDEX FK_5ce88c7684e3467d947c207d22b (phoneid),
  INDEX FK_61c94618481648dea319518cbc5 (officeid),
  INDEX FK_62ff25b2069445a798d2a81be62 (officeid),
  INDEX FK_63c503b1693b4edab33df506167 (phoneid),
  INDEX FK_7556da2fe48a490883495401669 (officeid),
  INDEX FK_757e6bceab9c4fbc9b4c7e500f0 (phoneid),
  INDEX FK_795ce9197aff4c86b756b189874 (phoneid),
  INDEX FK_8d817b94ce924ceeb19e0d57095 (phoneid),
  INDEX FK_8eea763d677544a1aff268f9175 (officeid),
  INDEX FK_a01c5300bc7948fab0c0044809c (officeid),
  INDEX FK_a38f552b50c34e438178e9f738e (phoneid),
  INDEX FK_a6f7b8b48b4a4834976dec30218 (officeid),
  INDEX FK_a929b9306a6545bdad3fdd1f376 (phoneid),
  INDEX FK_ad1d7a367a634ed3a453eabe609 (phoneid),
  INDEX FK_af018c8f107b4b21b080954cecf (phoneid),
  INDEX FK_af9b7b7c4f71445a9dbcfd438d4 (phoneid),
  INDEX FK_b78f38b0a96b4fc380f3ab8ad1b (phoneid),
  INDEX FK_b79665a961f047cfa94702f5ac5 (phoneid),
  INDEX FK_b9fae29e31d8410a94240950d63 (phoneid),
  INDEX FK_ba3eebd0ae1c4d2ab9da62ed5e6 (officeid),
  INDEX FK_be39d2a10d2a4ac98b5671d964b (officeid),
  INDEX FK_c012ad90c8e64fa3bba575bd395 (officeid),
  INDEX FK_cd24d6daefed4f5f8598e94e12a (officeid),
  INDEX FK_d00a1fd0da694456a34db12e202 (officeid),
  INDEX FK_d4d80ee837c747169b3284477d0 (phoneid),
  INDEX FK_d53efebae6cb4b2fa10528d0123 (officeid),
  INDEX FK_d5aa202411cd469999bf8cc947e (officeid),
  INDEX FK_db4ee5a3c71747f6972595ffad0 (officeid),
  INDEX FK_dda69461e7fd4f8ea2c9f23c4f5 (officeid),
  INDEX FK_de1b847b046b4eaea91c9485e15 (phoneid),
  INDEX FK_deec792432184dd0822cae30912 (officeid),
  INDEX FK_df6c92b99f634611ab32b19aaf1 (officeid),
  INDEX FK_e07b52ab69484beba7f938f2eeb (officeid),
  INDEX FK_e0fa6b635f8e4eb095a6becff47 (phoneid),
  INDEX FK_e4597b25a93c470eb354102cc67 (phoneid),
  INDEX FK_e522730dc93f4be0b05d680c8f0 (officeid),
  INDEX FK_e53c279eadfe4cc1bd9e91d4e0a (officeid),
  INDEX FK_ecac4c3a83654f7daffc813bb9c (officeid),
  INDEX FK_f2bcddc041e4484e9c0ef6f2c42 (phoneid),
  INDEX FK_fd87feca066e4f578e8c9cafefe (officeid),
  INDEX FK_fdf0eab34d254fe8bf174aa5783 (phoneid)
)
ENGINE = MYISAM
AUTO_INCREMENT = 7
AVG_ROW_LENGTH = 21
CHARACTER SET utf8
COLLATE utf8_general_ci;

--
-- Описание для таблицы users
--
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INT(11) NOT NULL AUTO_INCREMENT,
  login VARCHAR(255) NOT NULL,
  password VARCHAR(255) NOT NULL,
  salt VARCHAR(255) DEFAULT NULL,
  lastname VARCHAR(255) NOT NULL,
  firstname VARCHAR(255) NOT NULL,
  middlename VARCHAR(255) NOT NULL,
  isadmin INT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE INDEX login (login)
)
ENGINE = MYISAM
AUTO_INCREMENT = 17
AVG_ROW_LENGTH = 4611
CHARACTER SET utf8
COLLATE utf8_general_ci
ROW_FORMAT = FIXED;

-- 
-- Вывод данных для таблицы manufactors
--
INSERT INTO manufactors VALUES
(1, 'Samsung', 'Корея'),
(2, 'LG', 'Корея'),
(3, 'Lenovo', 'Китай'),
(4, 'Nokia', 'Финляндия'),
(5, 'Blackberry', 'Канада'),
(6, 'Apple', 'Америка'),
(7, 'HTC', 'Тайвань'),
(8, 'Sony', 'Япония'),
(9, 'Alcatel', 'Франция'),
(12, 'Philips', 'Нидерланды');

-- 
-- Вывод данных для таблицы offices
--
INSERT INTO offices VALUES
(1, 'Офис 1', 'Адрес 1'),
(2, 'Офис 2', 'Адрес 2'),
(5, 'Офис 3', 'Адрес 3');

-- 
-- Вывод данных для таблицы phones
--
INSERT INTO phones VALUES
(11, 2014, 1, 'Samsung S3'),
(19, 2014, 1, 'Samsung S4'),
(3, 2014, 6, 'Iphone 4S'),
(4, 2014, 6, 'Iphone 5S'),
(6, 2014, 12, 'Philips A3'),
(7, 2014, 3, 'Lenovo Y'),
(8, 2014, 8, 'Sony Xperia Z'),
(9, 2014, 4, 'Nokia Lumia'),
(10, 2014, 9, 'Alcatel One Touch');

-- 
-- Вывод данных для таблицы sales
--
INSERT INTO sales VALUES
(2, 3, 2, '2014-06-11', 200.00),
(4, 4, 1, '2014-06-09', 300.00),
(5, 11, 5, '2014-06-01', 238.00),
(6, 11, 1, '2014-06-09', 0.00);

-- 
-- Вывод данных для таблицы users
--
INSERT INTO users VALUES
(13, 'admin', 'ece17a9d98d1fb03a4595e4c74be0c7e2427e79d87643f90a907985d41c405dc', '295b5c5251e555b1', 'Админов', 'Админ', 'Админович', 1),
(15, 'user', '', NULL, 'Пользователев', 'Пользователь', 'Пользователевич', 0);

-- 
-- Включение внешних ключей
-- 
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;